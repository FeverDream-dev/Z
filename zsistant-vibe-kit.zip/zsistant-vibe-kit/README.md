# Zsistant Vibe-Coding Kit

This ZIP is **not an implementation repo**. It is a build map, design pack, prompt pack, brand starter, and OpenCode briefing folder for creating **Zsistant** with the `zazi` CLI.

The goal is to let you open this folder in OpenCode and watch each phase be implemented, tested, reviewed, and improved step by step.

## What this kit contains

- Product brief and implementation map.
- OpenCode agent instructions for the coding agent named **Z Assistant**.
- Phase-by-phase build prompts that you can paste into OpenCode.
- UI wireframes, generated placeholder logos, banners, icons, and avatar assets.
- Security and isolation rules.
- Channel integration specs for Telegram, Discord, WhatsApp, local web chat, and CLI.
- LLM router and resilience design.
- Persona trainer design for adapting tone, style, and workflow to each user.
- ClawHub/OpenClaw migration and external-skill analysis design.
- Release policy with human approval gate.

## What this kit intentionally does not contain

- No Go, TypeScript, JavaScript, Python, shell, or app source files.
- No generated daemon code.
- No generated web UI code.
- No real API keys, tokens, secrets, or credentials.
- No third-party logos copied from the web.

OpenCode should generate the code **inside this folder** after reading the specs.

## Recommended first steps

1. Unzip this folder into a clean workspace.
2. Open the folder with OpenCode.
3. Ask OpenCode to read:
   - `AGENTS.md`
   - `.opencode/agents/z-assistant.md`
   - `docs/00-master-map.md`
   - `docs/01-product-brief.md`
   - `phases/phase-00-repo-foundation.md`
4. Paste the prompt from `prompts/opencode/00-start-here.md`.
5. Let OpenCode implement only Phase 00 first.
6. Run the requested tests locally.
7. Continue phase by phase.

## Core identity

- Product name: **Zsistant**
- CLI command: **`zazi`**
- Coding agent name: **Z Assistant**
- Motto: **Many agents. One light host. Your machine stays in control.**

## Philosophy

Zsistant should feel like a lightweight local control tower for many personal/company agents. It should be simple enough for a non-technical user, but structured enough for a developer to inspect every decision, endpoint, prompt, and permission.

The main differentiator is not only “agent features.” It is **speed, loop status, proactivity, stability, isolation, and many agents on modest hardware**.
